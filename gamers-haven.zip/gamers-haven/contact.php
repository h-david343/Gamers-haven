<?php
$name = $_POST['name'];
$emali = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

/*echo($emali);
   echo($name);
   echo($subject);
   echo($message);*/

$txt = <<<kki
Name ---- $name \n
Email ---- $emali \n
Subject ---- $subject \n
Message ---- $message
kki;

$success = mail('g.dav040@gmail.com', $subject, $txt);
if ($success) {
    echo "true";
} else {
    echo "false";
}

?>